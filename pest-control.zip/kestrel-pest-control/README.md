# Kestrel Pest Control

Single-page marketing site for a fictional UK pest control business (Sheffield). Frontend demo only.

- One self-contained `index.html` (HTML, CSS and vanilla JS, with the photos embedded). No build step.
- Fonts (Sora, Inter) load from Google Fonts.
- The "Get Your Free Quote" popup is a mocked connector: it validates the form and shows a demo reference. Nothing is sent anywhere.
- Business details, prices and reviews are placeholders (`data-placeholder` attributes mark them).

## Run locally

Open `index.html` in a browser, or serve the folder:

    python3 -m http.server 8000

## Deploy

Works on GitHub Pages, Netlify or Vercel as a static site. Publish the folder root.
